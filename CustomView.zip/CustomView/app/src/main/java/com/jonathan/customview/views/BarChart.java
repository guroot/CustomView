package com.jonathan.customview.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public class BarChart extends View {

    public BarChart(Context context) {
        super(context);
    }

    public BarChart(Context context, @androidx.annotation.Nullable AttributeSet attrs) {
        super(context, attrs);
    }
}
